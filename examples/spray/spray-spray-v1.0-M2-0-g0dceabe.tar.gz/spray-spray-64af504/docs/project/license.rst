License
=======

.. literalinclude:: /../LICENSE