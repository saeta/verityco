Mailing List
============

Please use the active and friendly `Mailing List`_ for all your needs with regard to support, feedback and
general discussion!

You can also follow us on twitter: `@spraycc`_

.. _`Mailing list`: https://groups.google.com/group/spray-user/
.. _`@spraycc`: http://twitter.com/spraycc