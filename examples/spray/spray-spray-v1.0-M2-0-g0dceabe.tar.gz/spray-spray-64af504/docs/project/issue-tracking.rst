Issue-tracking
==============

Currently *spray* uses the `Issues Page`_ of the projects `github repository`_ for issue management.
If you find a bug and would like to report it please go there and create an issue.

If you are unsure, whether the problem you've found really is a bug please ask on the `Mailing List`_ first.

.. _`Issues Page`: https://github.com/spray/spray/issues
.. _`github repository`: https://github.com/spray/spray/
.. _`Mailing list`: https://groups.google.com/group/spray-user/