Sponsors
========

The following companies and organisations have kindly agreed to supply the *spray* development team with
free open-source licenses of their excellent development tools:

Jetbrains_
  We use `IntelliJ IDEA Ultimate` as the Scala IDE of our choice.

YourKit_
  YourKit is kindly supporting open source projects with its full-featured Java Profiler.
  YourKit, LLC is the creator of innovative and intelligent tools for profiling
  Java and .NET applications. Take a look at YourKit's leading software products:
  `YourKit Java Profiler`_ and `YourKit .NET Profiler`_.

.. _Jetbrains: http://www.jetbrains.com/
.. _`IntelliJ IDEA Ultimate`: http://www.jetbrains.com/idea/
.. _YourKit: http://www.yourkit.com
.. _`YourKit Java Profiler`: http://www.yourkit.com/java/profiler/index.jsp
.. _`YourKit .NET Profiler`: http://www.yourkit.com/.net/profiler/index.jsp