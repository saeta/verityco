Project Information
===================

.. toctree::
   :maxdepth: 2

   mailing-list
   building-spray
   issue-tracking
   patch-policy
   changelog
   license
   credits
   organisations-using-spray
   sponsors
