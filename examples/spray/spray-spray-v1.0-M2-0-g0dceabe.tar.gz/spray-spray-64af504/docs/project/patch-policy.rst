Patch Policy
============

Contributions to the project, no matter what kind, are always very welcome.
However, patches can only be accepted from their original author.

Along with any patches, please state that the patch is your original work and
that you license the work to the *spray* project under the project’s open source license.