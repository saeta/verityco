/*
 * Copyright (C) 2011-2012 spray.cc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package cc.spray.can
package client

import akka.event.LoggingAdapter
import cc.spray.io._
import parsing._
import rendering.HttpRequestPartRenderingContext
import collection.mutable.Queue
import model._
import java.nio.ByteBuffer
import annotation.tailrec

object ResponseParsing {

  private val UnmatchedResponseErrorState = ErrorState("Response to non-existent request")

  def apply(settings: ParserSettings, log: LoggingAdapter): DoublePipelineStage = new DoublePipelineStage {

    def build(context: PipelineContext, commandPL: Pipeline[Command], eventPL: Pipeline[Event]): Pipelines = {

      new Pipelines {
        var currentParsingState: ParsingState = UnmatchedResponseErrorState
        val openRequestMethods = Queue.empty[HttpMethod]

        def startParser = new EmptyResponseParser(settings, openRequestMethods.head == HttpMethods.HEAD)

        @tailrec
        final def parse(buffer: ByteBuffer) {
          currentParsingState match {
            case x: IntermediateState =>
              if (buffer.remaining > 0) {
                currentParsingState = x.read(buffer)
                parse(buffer)
              } // else wait for more input

            case x: HttpMessagePartCompletedState => x.toHttpMessagePart match {
              case part: HttpMessageEndPart =>
                eventPL(part)
                openRequestMethods.dequeue()
                if (openRequestMethods.isEmpty) {
                  currentParsingState = UnmatchedResponseErrorState
                  if (buffer.remaining > 0) parse(buffer) // trigger error if buffer is not empty
                } else {
                  currentParsingState = startParser
                  parse(buffer)
                }
              case part =>
                eventPL(part)
                currentParsingState = new ChunkParser(settings)
                parse(buffer)
            }

            case _: Expect100ContinueState =>
              currentParsingState = ErrorState("'Expect: 100-continue' is not allowed in HTTP responses")
              parse(buffer) // trigger error

            case ErrorState(_, -1) => // if we already handled the error state we ignore all further input

            case ErrorState(message, _) =>
              log.warning("Received illegal response: {}", message)
              commandPL(IoPeer.Close(ProtocolError(message)))
              currentParsingState = ErrorState("", -1) // set to "special" ErrorState that ignores all further input
          }
        }

        val commandPipeline: CPL = {
          case x: HttpRequestPartRenderingContext =>
            def register(req: HttpRequest) {
              openRequestMethods.enqueue(req.method)
              if (currentParsingState eq UnmatchedResponseErrorState) currentParsingState = startParser
            }
            x.requestPart match {
              case x: HttpRequest => register(x)
              case x: ChunkedRequestStart => register(x.request)
              case _ =>
            }
            commandPL(x)

          case cmd => commandPL(cmd)
        }

        val eventPipeline: EPL = {
          case x: IoPeer.Received => parse(x.buffer)
          case ev => eventPL(ev)
        }
      }
    }
  }
}